﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AppCarros
{
    public partial class FormContrato : Form
    {
        public FormContrato()
        {
            InitializeComponent();
        }

        private void FormContrato_Load(object sender, EventArgs e)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = new SqlCommand("Select nome FROM funcionario", con);
            SqlDataReader dr = cmd.ExecuteReader();
            AutoCompleteStringCollection mycollection = new AutoCompleteStringCollection();

            while (dr.Read())
            {
                mycollection.Add(dr.GetString(0));
            }
            txtNomeFuncionario.AutoCompleteCustomSource = mycollection;
            dr.Close();


            SqlCommand cmd2 = new SqlCommand("Select nome from Cliente", con);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            AutoCompleteStringCollection mycollection2 = new AutoCompleteStringCollection();
            while (dr2.Read())
            {
                mycollection2.Add(dr2.GetString(0));
            }
            txtNomeCliente.AutoCompleteCustomSource = mycollection2;
            dr2.Close();
            con.Close();

            Contrato con2 = new Contrato();
            List<Contrato> contratos = con2.listacontrato();
            DGV.DataSource = contratos;
        }

        private void btnNomeCliente_Click(object sender, EventArgs e)
        {
            clientecontrato cliente = new clientecontrato();
            cliente.LocalizarNomeCliente(txtNomeCliente.Text);
            txtIdCliente.Text = Convert.ToString(cliente.Id);
            txtTelefoneCliente.Text = cliente.celular;
            txtCPFCliente.Text = cliente.cpf;
        }

        private void btnIdCliente_Click(object sender, EventArgs e)
        {
            clientecontrato cliente = new clientecontrato();
            int id = Convert.ToInt32(txtIdCliente.Text.Trim());
            cliente.LocalizarIdCliente(id);
            txtNomeCliente.Text = cliente.nome;
            txtTelefoneCliente.Text = cliente.celular;
            txtCPFCliente.Text = cliente.cpf;
        }

        private void btnLocalizarIdFuncionario_Click(object sender, EventArgs e)
        {
            funcionariocontrato funcionariocontrato = new funcionariocontrato();
            int a = Convert.ToInt32(txtIdFuncionario.Text.Trim());
            funcionariocontrato.LocalizarIdFuncionario(a);
            txtNomeFuncionario.Text = funcionariocontrato.nome;
            txtTelefoneFuncionario.Text = funcionariocontrato.celular;
            txtCPFFuncionario.Text = funcionariocontrato.cpf;
        }

        private void btnLocalizarIdVeiculo_Click(object sender, EventArgs e)
        {
            carrocontrato carrocontrato = new carrocontrato();
            int a = Convert.ToInt32(txtIdCarro.Text.Trim());
            carrocontrato.LocalizarCarro(a);
            txtMarca.Text = carrocontrato.marca;
            txtModelo.Text = carrocontrato.modelo;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            DateTime dta1 = dateTimePicker1.Value;
            DateTime dta2 = dtpDevolucao.Value;
            int resultado = DateTime.Compare(dta1, dta2);
            if (resultado < 0)
            {
                contrato contrato = new contrato();
                int a = Convert.ToInt32(txtIdCliente.Text.Trim());
                int b = Convert.ToInt32(txtIdFuncionario.Text.Trim());
                int c = Convert.ToInt32(txtPreco.Text.Trim());
                int d = Convert.ToInt32(txtIdCarro.Text.Trim());
                contrato.CadastrarContrato(dateTimePicker1.Value, dtpDevolucao.Value, a, b, c, d);
                Contrato con2 = new Contrato();
                List<Contrato> contratos = con2.listacontrato();
                DGV.DataSource = contratos;
                MessageBox.Show("Contrato Cadastrado com sucesso!");

            }
            else
            {
                MessageBox.Show(Text = "Não é possivel colocar uma data antes do dia atual na devolução");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            contrato contrato = new contrato();
            int a = Convert.ToInt32(txtIcContrato.Text.Trim());
            contrato.deletarcontrato(a);
            MessageBox.Show("Contrato Apagado com Sucesso!");
            Contrato con2 = new Contrato();
            List<Contrato> contratos = con2.listacontrato();
            DGV.DataSource = contratos;
            txtIdCliente.Text = "";
            txtCPFCliente.Text = "";
            txtTelefoneCliente.Text = "";
            txtNomeCliente.Text = "";
            txtTelefoneFuncionario.Text = "";
            txtCPFFuncionario.Text = "";
            txtNomeFuncionario.Text = "";
            txtIdFuncionario.Text = "";
            txtPreco.Text = "";
            txtMarca.Text = "";
            txtModelo.Text = "";
            txtIdCarro.Text = "";
            txtIcContrato.Text = "";
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            contrato contrato = new contrato();
            int a = Convert.ToInt32(txtIcContrato.Text.Trim());
            contrato.localizarconrato(a);
            clientecontrato clientecontrato = new clientecontrato();
            int b = Convert.ToInt32(contrato.clienteid);
            clientecontrato.LocalizarIdCliente(b);
            txtIdCliente.Text = Convert.ToString(contrato.clienteid);
            txtNomeCliente.Text = clientecontrato.nome;
            txtTelefoneCliente.Text = clientecontrato.celular;
            txtCPFCliente.Text = clientecontrato.cpf;
            funcionariocontrato funcionariocontrato = new funcionariocontrato();
            int c = Convert.ToInt32(contrato.funcionarioid);
            funcionariocontrato.LocalizarIdFuncionario(c);
            txtIdFuncionario.Text = Convert.ToString(contrato.funcionarioid);
            txtNomeFuncionario.Text = funcionariocontrato.nome;
            txtTelefoneFuncionario.Text = funcionariocontrato.celular;
            txtCPFFuncionario.Text = funcionariocontrato.cpf;
            carrocontrato carrocontrato = new carrocontrato();
            int d = Convert.ToInt32(contrato.carroid);
            carrocontrato.LocalizarCarro(d);
            txtIdCarro.Text = Convert.ToString(contrato.carroid);
            txtMarca.Text = carrocontrato.marca;
            txtModelo.Text = carrocontrato.modelo;
            txtPreco.Text = Convert.ToString(contrato.preco);
            DateTime aa = Convert.ToDateTime(contrato.datafinal);
            dtpDevolucao.Value = aa;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtIdCliente.Text = "";
            txtCPFCliente.Text = "";
            txtTelefoneCliente.Text = "";
            txtNomeCliente.Text = "";
            txtTelefoneFuncionario.Text = "";
            txtCPFFuncionario.Text = "";
            txtNomeFuncionario.Text = "";
            txtIdFuncionario.Text = "";
            txtPreco.Text = "";
            txtMarca.Text = "";
            txtModelo.Text = "";
            txtIdCarro.Text = "";
            txtIcContrato.Text = "";
        }
    }
}
